INSERT INTO userlogin (uid,password) VALUES
  ('abc@gmail.com','1234'),
  ('xyz@gmail.com','1234');